import java.util.*;

public class TaskMinder extends Thread {
	private Vector<TaskEntry> taskEntries = new Vector<TaskEntry>();
	private long sleepInterval;

	public TaskMinder(long sleepInterval) {
		this.sleepInterval = sleepInterval;
	}

	public void addTaskEntry(TaskEntry taskEntry) {
		this.taskEntries.add(taskEntry);
	}

	public Vector<TaskEntry> getTaskEntries() {
		return this.taskEntries;
	}

	public long getSleepInterval() {
		return this.sleepInterval;
	}
	public void setSleepInterval(long sleepInterval) {
		this.sleepInterval = sleepInterval;
	}

	public void run() {
		while(true) {
			try {
				sleep(sleepInterval);
				long now = System.currentTimeMillis();

				for (TaskEntry taskEntry : taskEntries) {
					if (taskEntry.getRepeatInterval() + taskEntry.getTimeLastDone() <= now) {
						taskEntry.getTask().performTask();
						taskEntry.setTimeLastDone(now);
					}
				}
			}
			catch (Exception e) {
				System.out.println("Interrupted sleep : " + e);
			}
		}
	}
}
