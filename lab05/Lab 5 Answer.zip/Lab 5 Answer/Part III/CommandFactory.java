// CommandFactory.java
import java.util.Vector;

public interface CommandFactory {
	abstract public void setShapes(Vector shapes);
	abstract public Command create() throws Exception;
}
