// CircleCreation.java
import java.util.*;

public class CircleCreation implements Command {
	int _radius;
	Vector _shapes;
	Circle _circle;

	public CircleCreation(Vector shapes, int radius) {
		_shapes = shapes;
		_radius = radius;
		_circle = null;
	}

	public void execute() {
		_circle = new Circle(0,0, _radius);
		_shapes.add(_circle);
	}

	public void undo() {
		if (_circle != null)
			_shapes.remove(_circle);
	}
}
