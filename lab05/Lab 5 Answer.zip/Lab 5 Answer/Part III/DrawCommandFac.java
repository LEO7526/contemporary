// DrawCommandFac.java
import java.util.*;

public class DrawCommandFac implements CommandFactory {
	Vector _shapes;
	public DrawCommandFac() {
		_shapes = null;
	}

	public void setShapes(Vector shapes) {
		_shapes = shapes;
	}

	public Command create() throws Exception {
		return new DrawCommand(_shapes);
	}

}
