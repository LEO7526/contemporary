//RectangleCreation.java
import java.util.*;

public class RectangleCreation implements Command {
	int _width, _height;
	Vector _shapes;
	Rectangle _rectangle;

	public RectangleCreation(Vector shapes, int width, int height) {
		_shapes = shapes;
		_width = width;
		_height = height;
		_rectangle = null;
	}

	public void execute() {
		_rectangle = new Rectangle(0,0, _width, _height);
		_shapes.add(_rectangle);
	}

	public void undo() {
		if (_rectangle != null)
			_shapes.remove(_rectangle);
	}
}
