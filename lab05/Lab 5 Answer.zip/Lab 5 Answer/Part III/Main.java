// Main.java
import java.util.*;
import java.io.*;

public class Main {

	public static void main(String[] args) {
		Vector _shapes = new Vector();
		Vector _history = new Vector();
		String[] _factory = {"DrawCommandFac", "DeleteShapeFac", 
				"CircleCreationFac", "RectangleCreationFac"};
		CommandFactory[] _facs;
		boolean cont = true;
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		_facs = new CommandFactory[_factory.length];
		try {
			for (int i = 0; i < _facs.length; i++) {
				_facs[i] = (CommandFactory) Class.forName(_factory[i]).newInstance();
				_facs[i].setShapes(_shapes);
			}
			while (cont) {
				System.out.println("Enter command: 0 = exit, 1 = undo, 2 = draw all shapes, 3 = delete a shape, 4 = create circle, 5 = create rectangle");
				String line = br.readLine();
				int command = Integer.parseInt(line);
				if (command == 0)
					cont = false;
				else if (command == 1) {
					if (_history.size() > 0) {
						Command com = (Command) _history.remove(_history.size()-1);
						com.undo();
					}
				} else {
					Command com = _facs[command-2].create();
					if (!(com instanceof DrawCommand))
						_history.add(com);
					com.execute();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}