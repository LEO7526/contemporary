//DeleteShape.java
import java.util.*;

public class DeleteShape implements Command {
	Vector _shapes;
	Shape _shape;
	int _index;

	public DeleteShape(Vector shapes, int index) {
		_shapes = shapes;
		_index = index;
		_shape = null;
	}

	public void execute() {
		if (_index < _shapes.size() && _index >= 0) {
			_shape = (Shape) _shapes.remove(_index);
		} else {
			System.out.println("index is out of range.");
		}
	}

	public void undo() {
		if (_shape != null)
			_shapes.add(_index, _shape);
	}

}
