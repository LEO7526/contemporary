// DeleteShapeFac.java
import java.util.*;
import java.io.*;

public class DeleteShapeFac implements CommandFactory {
	Vector _shapes;

	public DeleteShapeFac() {
		_shapes = null;
	}

	public void setShapes(Vector shapes) {
		_shapes = shapes;
	}

	public Command create() throws Exception {
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		System.out.println("Enter index of the shape:");
		String line = br.readLine();
		int index = Integer.parseInt(line);
		return new DeleteShape(_shapes, index);
	}

}
