// DrawCommand.java
import java.util.*;

public class DrawCommand implements Command {
	Vector _shapes;

	public DrawCommand(Vector shapes) {
		_shapes = shapes;
	}

	public void execute() {
		for (int i = 0; i < _shapes.size(); i++)
			( (Shape) _shapes.elementAt(i)).draw();
	}

	public void undo() {
	}

}
