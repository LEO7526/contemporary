import java.util.Stack;

public class Main {
	public static void main(String[] args) {

		Stack commandStack = new Stack();
		Command[] com = new Command[5];

		com[0] = new Command1(1);
		com[1] = new Command2(2);
		com[2] = new Command2(3);
		com[3] = new Command1(4);
		com[4] = new Command1(5);

		// execute the commands in order
		System.out.println("Execute Comannds Begin");
		for (int i = 0; i < com.length; i++) {
			com[i].execute();
			commandStack.push(com[i]); // add the command in the stack
		}
		System.out.println();
		System.out.println("Undo Commands Begin");
		// undo the commands
		while (!commandStack.empty()) {
			// get the latest command in the stack
			Command c = (Command) commandStack.pop();
			// undo the latest command
			c.undo();
		}
	}
}