public class ObjectFractionAdapter implements Fraction {
	private LongFraction lf;
	
	public LongFraction getLongFraction() { return lf; }
	
	public ObjectFractionAdapter(int num, int denum) {
		lf = new LongFraction(num, denum);
	}
	
	public ObjectFractionAdapter(LongFraction l) {
		this.lf = l;
	}

	public Fraction add(Fraction b) {
		
		if (b instanceof ObjectFractionAdapter) {
			return new ObjectFractionAdapter(lf.plus(((ObjectFractionAdapter)b).getLongFraction()));
		} else
			return null;
		

	}

	public Fraction add(int b) {

			return new ObjectFractionAdapter(lf.plus((long)b));
	}

	public Fraction subtract(Fraction b) {
		if (b instanceof ObjectFractionAdapter) {
			return new ObjectFractionAdapter(lf.minus(((ObjectFractionAdapter)b).getLongFraction()));
		} else
			return null;
	}

	public Fraction subtract(int b) {

		return new ObjectFractionAdapter(lf.minus((long)b));
		
	}
	
	public int getNumerator() {
		return (int) lf.numerator();
	}

	public int getDenominator() {
		return (int) lf.denominator();
	}
	
	public String toString() {
		return lf.toString();
	}
}