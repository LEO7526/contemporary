public class ClassFractionAdapter extends LongFraction implements Fraction {
	public ClassFractionAdapter(int num, int denum) {
		super(num, denum);
	}

	public Fraction add(Fraction b) {
		
		if (b instanceof ClassFractionAdapter) {
			LongFraction lf = this.plus((LongFraction) b);
			return new ClassFractionAdapter((int)lf.numerator(), (int)lf.denominator());
		} else
			return null;
		

	}

	public Fraction add(int b) {

			LongFraction lf = this.plus((long)b);
			return new ClassFractionAdapter((int)lf.numerator(), (int)lf.denominator());

	}

	public Fraction subtract(Fraction b) {
		if (b instanceof ClassFractionAdapter) {
			LongFraction lf = this.minus((LongFraction)b);
			return new ClassFractionAdapter((int)lf.numerator(), (int)lf.denominator());
		} else
			return null;
	}

	public Fraction subtract(int b) {

			LongFraction lf = this.minus((long)b);
			return new ClassFractionAdapter((int)lf.numerator(), (int)lf.denominator());
		
	}
	
	public int getNumerator() {
		return (int) numerator();
	}

	public int getDenominator() {
		return (int) denominator();
	}
}