/**
 * Title: Sample Implementation of a One-to-One Association
 * Book: Object Oriented Technology: From Diagram to Code
 * Author: Curtis Tsang, Clarence Lau, YK Leung
 * Publisher: McGraw-Hill
 * @version 1.0
 */
import java.util.*;

class ClassA {

  Hashtable _Bs; // a collection for keeping the associated ClassB objects

  public ClassA() {
    _Bs = new Hashtable();
  }

  // retrieves the associated ClassB objects from the collection
  public Enumeration getBs() {
    return (_Bs.elements());
  }

  // retrieves the associated ClassB object from the collection using a key
  public ClassB getClassB(int key) {
    return((ClassB) _Bs.get(new Key(key)));
  }

  // link an ClassB object to this object
  public void addB(ClassB b, int key) {
    _Bs.put(new Key(key), b);
  }

  // remove the link between ClassB object to this
  // object
  public void removeB(ClassB b) {
    _Bs.remove(b);
  }
}

class Key {
  int _key;
  public Key(int key) {
    _key = key;
  }

  public boolean equals(Object obj) {
    if (obj instanceof Key)
      return ( ( (Key) obj)._key == _key);
    else
      return (false);
  }

  public int hashCode() {
    return (_key);
  }
}// Key

class ClassB {
	ClassA _a; // local reference for linking a ClassA object

        // for setting the link to a ClassA object
	public void setA(ClassA a)
	{
		_a = a;
	}

        // for retrieval of the link of the ClassA object
	public ClassA getA()
	{
		return _a;
	}
}

public class Main {
	public static void main(String agrv[])
	{
		ClassA a = new ClassA();
		System.out.println("Object a " + a + " is created.");
                ClassB b1 = new ClassB();
		System.out.println("Object b1 " + b1 + " is created.");
                ClassB b2 = new ClassB();
		System.out.println("Object b2 " + b2 + " is created.");
		// set the links between the objects
		a.addB(b1, 1);
                a.addB(b2, 2);
		b1.setA(a);
                b2.setA(a);
		// test the links
                // retrieve object b1 using the key
                System.out.println("object a " + a + " has a link to object b1 " + a.getClassB(1));
                System.out.println("object b1 " + b1 + " has a link to object a " + b1.getA());
                System.out.println("object b2 " + b2 + " has a link to object a " + b2.getA());
	}
}