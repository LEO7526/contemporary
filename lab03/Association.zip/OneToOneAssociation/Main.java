/**
 * Title: Sample Implementation of a One-to-One Association
 * Book: Object Oriented Technology: From Diagram to Code
 * Author: Curtis Tsang, Clarence Lau, YK Leung
 * Publisher: McGraw-Hill
 * @version 1.0
 */

class ClassA {
	ClassB _b; // local reference for linking a ClassB object

        // for setting the link to a ClassB object
	public void setB(ClassB b)
	{
		_b = b;
	}

        // for retrieval of the link of the ClassB object
	public ClassB getB()
	{
		return _b;
	}
}

class ClassB {
	ClassA _a; // local reference for linking a ClassA object

        // for setting the link to a ClassA object
	public void setA(ClassA a)
	{
		_a = a;
	}

        // for retrieval of the link of the ClassA object
	public ClassA getA()
	{
		return _a;
	}
}

public class Main {
	public static void main(String agrv[])
	{
		ClassA a = new ClassA();
		System.out.println("Object a " + a + " is created.");
                ClassB b = new ClassB();
		System.out.println("Object b " + b + " is created.");
		// set the links between the objects
		a.setB(b);
		b.setA(a);
		// test the link
		System.out.println("object a " + a + " has a link to object b " + a.getB());
                System.out.println("object b " + b + " has a link to object a " + b.getA());
	}
}