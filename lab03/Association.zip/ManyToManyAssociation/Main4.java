/**
 * Title: Sample Implementation of a Many-to-Many Association
 * Book: Object Oriented Technology: From Diagram to Code
 * Authors: Curtis Tsang, Clarence Lau, YK Leung
 * Publisher: McGraw-Hill
 * @version 1.0
 */

import java.util.*;
class School {
  private String _name;
  private Vector _registrations; // for keeping the references to registration objects

  public School(String name) {
    _name = name;
    _registrations = new Vector();
  }

  public void setName(String name) {
    _name = name;
  }

  public String getName() {
    return(_name);
  }

  // for adding a registration object to the collection
  public void addRegistration(Registration reg) {
    _registrations.add(reg);
  }
  // for removing a registration object to the collection
  public void removeRegistration(Registration reg) {
    _registrations.remove(reg);
  }

  // for retrieving the associated students
  public Enumeration getStudents() {
    int i;
    Vector students = new Vector();

    for (i = 0; i < _registrations.size(); i++)
        students.add(((Registration) _registrations.elementAt(i)).getStudent());
    return(students.elements());
  }
}

class Person {
  private String _name;
  private Vector _registrations; // for keeping the references to registration objects

  public Person(String name) {
    _name = name;
    _registrations = new Vector();
  }

  String getName() {
    return(_name);
  }

  void setName(String name) {
    _name = name;
  }

  // for adding a registration object to the collection
  public void addRegistration(Registration reg) {
    _registrations.add(reg);
  }

  // for removing a registration object to the collection
  public void removeRegistration(Registration reg) {
    _registrations.remove(reg);
  }

  // for retrieving the associated schools
  public Enumeration getSchools() {
    int i;
    Vector schools = new Vector();

    for (i = 0; i < _registrations.size(); i++)
      schools.add(((Registration) _registrations.elementAt(i)).getSchool());
    return(schools.elements());
  }
}

class Registration {
  private Person _student; // reference to the student object
  private School _school; // reference to the school object
  private int _studentNo; // the attribute of the association class

  private Registration(Person student, School school, int studentNo) {
    _school = school;
    _student = student;
    _studentNo = studentNo;
  }

  static public void register(Person student, School school, int studentNo) {
    Registration reg = new Registration(student, school, studentNo);
    school.addRegistration(reg);
    student.addRegistration(reg);
  }

  public void deregister() {
    this._school.removeRegistration(this);
    this._student.removeRegistration(this);
  }

  public School getSchool() {
    return(_school);
  }

  public Person getStudent() {
    return(_student);
  }

}


public class Main4 {

	public static void main(String argv[]) {
		int i;
                String schoolNames[] = {"TWGS", "KCTS", "LKP", "CMT", "KKY"};
                String studentNames[] = {"Peter Chan", "Alan Tong", "John Lee", "Venice Tsui", "Mary Lui"};
                Person students[] = new Person[5];
                School schools[] = new School[5];
		for (i = 0; i < 5; i++) {
                        students[i] = new Person(studentNames[i]);
                        schools[i] = new School(schoolNames[i]);
 		}
                Registration.register(students[0], schools[0], 1241);
                Registration.register(students[1], schools[1], 1234);
                Registration.register(students[2], schools[1], 1111);
                Registration.register(students[3], schools[2], 9878);
                Registration.register(students[4], schools[3], 6782);
                Registration.register(students[4], schools[4], 9807);
                Registration.register(students[4], schools[0], 9080);

                Enumeration s = students[4].getSchools();
                System.out.println("Mary Lui studies in the following schools:");
                for (;s.hasMoreElements();) {
                  System.out.println (((School) s.nextElement()).getName());
                }
	}

}
