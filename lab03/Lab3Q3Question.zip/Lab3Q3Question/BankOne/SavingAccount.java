

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Dr. Clarence LAU
 * @version 1.0
 */

package BankOne;

public class SavingAccount extends Account {
  public SavingAccount(String accountNumber, double balance) {
    super(accountNumber, balance);
  }

}