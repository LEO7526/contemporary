

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Dr. Clarence LAU
 * @version 1.0
 */

package BankOne;

public class LoanAccount extends Account {
  public LoanAccount(String accountNumber, double balance) {
    super(accountNumber, balance);
  }
}