package KWBank;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Dr. Clarence LAU
 * @version 1.0
 */
import BankOne.*;

public class IAAdapter extends InternationalAccount {
  Account _account;

  public IAAdapter(Account account) {
    _account = account;
  }

  Account getAccount() {
    return _account;
  }

  public void increase(double amount) {
    _account.credit(amount);
  }

  public void decrease(double amount) {
    _account.debit(amount);
  }

  public double showBalance() {
    return _account.getBalance();
  }

  public double showBalanceInUSD() {
    return getCalculator().HKD2USD(_account.getBalance());
  }

  public String getAccountNumber() {
    return _account.getAccountNumber();
  }

  public String getCurrency() {
    return InternationalAccount.HKD;
  }

}