package KWBank;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Dr. Clarence LAU
 * @version 1.0
 */
import BankOne.*;
import java.util.*;

public class ClientAdapter extends Client {
  Customer _customer;

  public ClientAdapter(Customer customer) {
    super();
    _customer = customer;
  }

  public String getName() {
    return _customer.getName();
  }

  public String getAddress() {
    return _customer.getAddress();
  }

  public void addInternationalAccount(InternationalAccount ia) {
    // only allow to add account to customer
    if (ia instanceof IAAdapter) {
      _customer.addAccount(((IAAdapter) ia).getAccount());
    }
  }

  public void removeInternationalAccount(InternationalAccount ia) {
    // only allow to remove account from customer
    if (ia instanceof IAAdapter) {
      _customer.removeAccount(((IAAdapter) ia).getAccount());
    }
  }

  public Enumeration getInternationalAccounts() {

    Vector ias = new Vector();
    Enumeration accounts = _customer.getAccounts();
    ForeignExchangeCalculator calculator = new ForeignExchangeCalculator();
    while (accounts.hasMoreElements()) {
      IAAdapter ia = new IAAdapter((Account) accounts.nextElement());
      ia.setClient(this);  // set the link between the International Account and Client
      ia.setCalculator(calculator);  // set the link between the Calculator and the International Account
      ias.add(ia);
    }
    return ias.elements();
  }

}