package KWBank;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Dr. Clarence LAU
 * @version 1.0
 */

public class ForeignExchangeCalculator {
  public ForeignExchangeCalculator() {
  }

  public double HKD2USD(double amount) {
    return amount/7.8;
  }
}