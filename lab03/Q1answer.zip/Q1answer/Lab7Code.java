import java.awt.Point;


interface OldCircle {
	public double [] getCoeff( );
}

interface NewCircle {
	public double getRadius( );
	public Point getCenter( );
}

class OldCircleImpl implements OldCircle {
	private double [] coeff = new double[3];
	public OldCircleImpl(double a, double b, double c) {
		coeff[0] = a; coeff[1] = b; coeff[2] = c;
	}
	public double [ ] getCoeff( ) {
		return coeff;
	}
}

class PrintCircle {
	public static void printCircle(NewCircle newCircle) {
		System.out.println("r = " + newCircle.getRadius( ));
		System.out.println("center = [" + newCircle.getCenter( ).getX() +
							", " + newCircle.getCenter( ).getY() + "]");
	}
}




