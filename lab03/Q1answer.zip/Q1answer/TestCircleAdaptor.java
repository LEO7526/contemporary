import java.awt.Point;

public class TestCircleAdaptor {
	public static void main(String [] args) {
		OldCircleImpl oldCircle = new OldCircleImpl(10.0, 15.0, 25.5);
		NewCircle newCircle = new CircleObjectAdapter(oldCircle);
		PrintCircle.printCircle(newCircle);
		NewCircle newCircle2 = new CircleClassAdapter(10.0, 15.0, 25.5);
		PrintCircle.printCircle(newCircle2);
	}
}

class CircleObjectAdapter implements NewCircle {
	private OldCircle oldCircle;

	public CircleObjectAdapter(OldCircle oldCircle) {
		this.oldCircle = oldCircle;
	}

	public double getRadius() {
		double [] coeff = oldCircle.getCoeff();
		return Math.sqrt(coeff[2]);
	}

	public Point getCenter(){
		double [] coeff = oldCircle.getCoeff();
		Point p = new Point();
		p.setLocation(coeff[0], coeff[1]);
		return p;
	}
}

class CircleClassAdapter extends OldCircleImpl implements NewCircle {

	public CircleClassAdapter(double a, double b, double c) {
		super(a, b, c);
	}

	public double getRadius() {
		double [] coeff = getCoeff();
		return Math.sqrt(coeff[2]);
	}

	public Point getCenter(){
		double [] coeff = getCoeff();
		Point p = new Point();
		p.setLocation(coeff[0], coeff[1]);
		return p;
	}
}

interface OldCircle {
	public double [] getCoeff( );
}

interface NewCircle {
	public double getRadius( );
	public Point getCenter( );
}

class OldCircleImpl implements OldCircle {
	private double [] coeff = new double[3];
	public OldCircleImpl(double a, double b, double c) {
		coeff[0] = a; coeff[1] = b; coeff[2] = c;
	}
	public double [ ] getCoeff( ) {
		return coeff;
	}
}

class PrintCircle {
	public static void printCircle(NewCircle newCircle) {
		System.out.println("r = " + newCircle.getRadius( ));
		System.out.println("center = [" + newCircle.getCenter( ).getX() +
							", " + newCircle.getCenter( ).getY() + "]");
	}
}




