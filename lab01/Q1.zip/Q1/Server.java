public class Server {

  public void doService() {
    System.out.println("Server: doService");
  }

}