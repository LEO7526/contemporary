public class Server2 extends Server {

  public void doService() {
    System.out.println("Server2: doService");
  }

}