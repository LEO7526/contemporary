public class Server implements ServerInterface {

  public void doService() {
    System.out.println("Server: doService");
  }

}