public interface ServerInterface {
  public abstract void doService();
}