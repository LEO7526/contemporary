public class Server2 implements ServerInterface {

  public void doService() {
    System.out.println("Server2: doService");
  }

}