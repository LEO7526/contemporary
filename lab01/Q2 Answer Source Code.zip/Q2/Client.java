public class Client {

  public void doAction() {
    System.out.println("Client: doAction");
    Server s = new Server();
    s.doService();
  }  

}