public class Main {

	public static void main(String[] args) {
		Cal cal = new Cal();
		cal.compute();
	}
}