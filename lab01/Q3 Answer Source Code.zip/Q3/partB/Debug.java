public interface Debug {
	abstract public void log(String message);
}