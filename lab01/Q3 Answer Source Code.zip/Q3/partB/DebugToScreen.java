public class DebugToScreen implements Debug {
	public void log(String message) {
		System.out.println(message);
	}

}