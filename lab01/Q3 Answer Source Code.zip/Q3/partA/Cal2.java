import java.io.*;

public class Cal2 extends Cal {
	PrintWriter out;
	
	public Cal2() {
		try {
			FileWriter outputFile = new FileWriter("log.txt");
			out = new PrintWriter(outputFile);
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	void log(String s) {
	    out.println(s);
		out.flush();
	}
	
}