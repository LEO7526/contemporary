
import java.awt.*;

public class DisplayUIAwtImp implements DisplayUI {
	private Frame frame;
	private Label label;

	public DisplayUIAwtImp () {
		frame = new Frame();
		label = new Label();
		frame.add(label,BorderLayout.CENTER);
		frame.setSize(50,50);
		frame.setVisible(true);
	}

	public void setText(String text) {
		label.setText(text);
		label.repaint();
	}
}