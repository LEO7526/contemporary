
public interface DisplayUI {
	abstract public void setText(String text);
}
