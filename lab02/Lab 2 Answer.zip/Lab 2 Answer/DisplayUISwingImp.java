
import java.awt.*;
import javax.swing.*;

public class DisplayUISwingImp implements DisplayUI {
	private JFrame frame;
	private JLabel label;

	public DisplayUISwingImp () {
		frame = new JFrame();
		label = new JLabel();
		frame.getContentPane().add(label,BorderLayout.CENTER);
		frame.setSize(50,50);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void setText(String text) {
		label.setText(text);
		label.repaint();
	}
}