import java.util.*;

public class Caretaker {
     Vector undoList;
     public Caretaker(){
            undoList = new Vector();
     }
     public void saveAccount(Account xaccount) {
            AccountMemento a = new AccountMemento(xaccount);
            undoList.addElement(a);
     }
     public void saveCustomer (Customer xcustomer) {
         CustomerMemento c = new CustomerMemento(xcustomer); 
         undoList.addElement(c);
     }
     public void undo() {
          if (undoList.size() > 0) {
              // get the last element in the undo list 
              Object obj = undoList.lastElement();
              Memento m = (Memento) obj;
              m.restore(); // restore the state of the orginator
              undoList.removeElement(obj);
          } // if end
     } // undo
     
} // Caretaker 