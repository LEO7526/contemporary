public class Account  {
    // package protected
    String accountNumber;
    float balance;

    public Account(String xaccountNumber, float xbalance) {
        accountNumber = xaccountNumber;  
        balance = xbalance;
    }
    public float getBalance() {
        return balance;
    }
    public String getAccountNumber() {
        return accountNumber;
    }
    public void decrease(float amount) {
        balance -= amount;
        System.out.println( "--- account no: " + accountNumber + " "
                           +"decrease amount: " + amount);
    }
    public void increase(float amount) {
        balance += amount;
        System.out.println( "--- account no: " + accountNumber + " "
                           +"increase amount: " + amount);
    }
    
} // Account

class AccountMemento implements Memento {
    // saved fields remember internal fields of the account
    
    Account maccount; // variable
    // package protected
    private String maccountNumber;
    private float mbalance;

    public AccountMemento(Account xaccount) {
         maccount = xaccount;  // store the reference or address of  object
         maccountNumber = maccount.accountNumber; // store the value of object
         mbalance = maccount.balance;            // store the value of object
    } // Memento 
    
    public void restore() {
      // restore the internal state of the specified account
      // by using the saved pointer
         maccount.accountNumber = maccountNumber; // restore the value
         maccount.balance = mbalance;             // restore the value
         System.out.println("restore account no: " + maccountNumber + " " 
                            + "balance" + " " + mbalance);
    } // restore
    
} // Memento 