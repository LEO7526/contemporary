public interface Memento {
  public void restore();
}