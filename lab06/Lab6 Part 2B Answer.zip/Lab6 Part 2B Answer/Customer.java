import java.util.*;
import java.util.Enumeration;

public class Customer  {

    String name;
    String address;
    Hashtable hash_account;
    
    public Customer(String xname, String xaddress) {
        name = xname;
        address = xaddress;
        hash_account = new Hashtable();
        System.out.println("Customer: " + xname + " " + "is created.");
    }

    public void addAccount(Account xaccount) {
        // System.out.println("hash size : " + hash_account.size());
        hash_account.put(xaccount.getAccountNumber(), xaccount);
        System.out.println("--- add account : " + xaccount.getAccountNumber());
        // System.out.println("hash size : " + hash_account.size());        
    }
    
    public void removeAccount(Account xaccount) {
        // System.out.println("hash size : " + hash_account.size());
        hash_account.remove(xaccount.getAccountNumber());
        System.out.println("--- remove account : " + xaccount.getAccountNumber());
        // System.out.println("hash size : " + hash_account.size());       
    }

    public Enumeration getAllAccounts() {
        return hash_account.elements();
    }
    
    public Account getAccount(String xaccountNumber) {
        Account x = (Account) hash_account.get(xaccountNumber);
        // System.out.println("get account : " + x.getAccountNumber());
        return x;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
    
} // Customer

class CustomerMemento implements Memento {
    private Customer mcustomer;
    private String mname;
    private String maddress;	
	private Hashtable mhash_account;  
	
    public CustomerMemento(Customer xcustomer) {
        mcustomer = xcustomer;
		mname = xcustomer.name;
		maddress = xcustomer.address;
		mhash_account = (Hashtable) xcustomer.hash_account.clone();        
    } 
    
    public void restore() {
		mcustomer.name = mname;
		mcustomer.address = maddress;
		mcustomer.hash_account = mhash_account;
    } 
    
} // CustomerMemento 
