import java.util.*;
import MyPackage.*;

public class Caretaker {
     private Vector undoList;
     public Caretaker(){
            undoList = new Vector();
     }
     public void saveMyClass(MyClass mc) {
            Memento amemento = new Memento(mc);
            undoList.add(amemento);
     }
     public void undo() {
          if (undoList.size() > 0) {
              Object obj = undoList.lastElement();
              Memento m = (Memento) obj;
              m.restore();
              undoList.removeElement(obj);
          }
     }
}